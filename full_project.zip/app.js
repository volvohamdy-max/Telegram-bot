const {Telegraf} = require('telegraf');
const fs = require('fs');
const schedule = require('node-schedule');

ADMIN=["@Mmlek"];
MyBot="@Spot_gainbot";
TOKEN='7313709513:AAEbh5gAlGGw7FrMGRhEMknIcieeyId8waA';
ID_channel="@tradingg0ld";
MyPocket="TARqGhrqiLCH3mxKVLey6vRy3e7CUN3XDY";
main_group_link="https://t.me/spotgain";
support_account="@Mmlek";

data={};
fs.readFile('data.json', 'utf8', (err, __data) => {if (err) {}else{data=JSON.parse(__data);}});
//function SaveData(){fs.writeFile("data.json", JSON.stringify(data), function(err) {if (err) {console.log(err);}});}
function SaveData(){fs.writeFileSync("data.json", JSON.stringify(data), function(err) {if (err) {console.log(err);}})}

const bot = new Telegraf(TOKEN ,{polling: true});
function start_button(ctx,__chk=0){
	if (data[ctx.from.id]==undefined)
	{
		__reff_="";
		if (__chk==1)
		{
			__reff=ctx.message.text.split(" ")[1];
			if (__reff!="" &&  __reff!=undefined)
			{
				__reff_=Buffer.from(__reff,'base64').toString();
				
				if (data[__reff_]==undefined){__reff_="";}
				else
				{
					__id=__reff_;
					for(i=0;i<4;i++)
					{
						if (data[__id]==undefined){break}
						else
						{
							data[__id].MyTeam[i].push(ctx.from.id);
							__id=data[__id].father;
						}
					}
				}
			}
		}
		
		data[ctx.from.id]=
		{
			Bal: 0,
			username: "@"+ctx.from.username,
			first_name: ctx.from.first_name,
			last_name: ctx.from.last_name,
			MyTeam: [[],[],[],[],[]],
			state:"",
			Bal_i_pending:0,
			Bal_d_pending:0,
			father : __reff_,
			Bal_Day_inc:0,
			myLang: 2,
			chat: ctx.chat.id
		};
		SaveData();
    }
	//if (data[ctx.from.id].myLang===0 || data[ctx.from.id].myLang===1 || data[ctx.from.id].myLang===2)
	{
		lang_=data[ctx.from.id].myLang;
		__L_str_=
		[["رصيد الحساب","تحويل","شحن الحساب","سحب الرصيد","نظام الإحالة","أعضاء فريقي","الدعم الفني","الجروب الرئيسي","English","Spanish"]
		,["Balance","Transferir","depósito","retiro","referencias","mi equipo","Apoyo","grupo principal","English","العربية"]
		,["Balance","Transfer","Deposit","Withdraw","Refferls","My team","Support","Main group","Spanish","العربية"]]
		__L_str=__L_str_[lang_]
		
		LT_str=
		["أهلا بك في البوت الخاص بنا"
		,"Bienvenida en nuestra bot"
		,"Welcome in our bot"];
		
		BTNs=[
			[
				{ text: __L_str[0], callback_data: 'Balance' },
			//],
			//[
				{ text: __L_str[1], callback_data: 'Transfer' },
			],
			[
				{ text: __L_str[2], callback_data: 'Deposit' },
			//],
			//[
				{ text: __L_str[3], callback_data: 'Withdraw' },
			],
			[
				{ text: __L_str[4], callback_data: 'Refferls' },
			//],
			//[
				{ text: __L_str[5], callback_data: 'My team' },
			],
			[
				{ text: __L_str[6], callback_data: 'Support' },
			//],
			//[
				{ text: __L_str[7], callback_data: 'Main group' },
			],
			[
				{ text: __L_str[8], callback_data: __L_str[8] },
			//],
			//[
				{ text: __L_str[9], callback_data: __L_str[9] },
			]
		]
		if (ADMIN.includes(data[ctx.from.id].username))
		{
		BTNs.push([{ text: "Deposit Admin", callback_data: 'Deposit_admin' }]);
		BTNs.push([{ text: "reset Admin", callback_data: 'reset_admin' }]);
		BTNs.push([{ text: "msg all Admin", callback_data: 'msg_all_admin' }]);
		}
		try{
		bot.telegram.sendMessage(ctx.chat.id, LT_str[lang_]
		,{
			reply_markup: {
				inline_keyboard: BTNs
			}
		})
		}catch(er){console.log(er)}
	}
	/*
	else
	{
		bot.telegram.sendMessage(ctx.chat.id, 'Please choose your Language:',{
			reply_markup: {
				keyboard: [
					[
						{ text: "English"},
					],
					[
						{ text: "Spanish"},
					],
					[
						{ text: "العربية"},
					]
				]
			}
		})
	}
	*/
}
//starting block
bot.command('start', ctx => {
	console.log(ctx.from)
	start_button(ctx,1);
})

bot.action('English', ctx => {
    data[ctx.from.id].myLang=2;
	start_button(ctx);
})
bot.action('العربية', ctx => {
    data[ctx.from.id].myLang=0;
	start_button(ctx);
})
bot.action('Spanish', ctx => {
    data[ctx.from.id].myLang=1;
	start_button(ctx);
})

bot.action('Deposit_admin', ctx => {
    if (data[ctx.from.id]==undefined)
	{
		start_button(ctx);
	}
	else
	{
		data[ctx.from.id].state="Deposit_admin";
		try{
		bot.telegram.sendMessage(ctx.chat.id, "ادخل المبلغ الذي تريد شحنه");
		}catch(er){console.log(er)}
	}
})

bot.action('reset_admin', ctx => {
    if (data[ctx.from.id]==undefined)
	{
		start_button(ctx);
	}
	else
	{
		data[ctx.from.id].state="reset_admin";
		try{
		bot.telegram.sendMessage(ctx.chat.id, "ادخل الآي دي للعضو الذي تريد تصفير حسابه");
		}catch(er){console.log(er)}
	}
})

bot.action('msg_all_admin', ctx => {
    if (data[ctx.from.id]==undefined)
	{
		start_button(ctx);
	}
	else
	{
		data[ctx.from.id].state="msg_all_admin";
		try{
		bot.telegram.sendMessage(ctx.chat.id, "اكتب رسالة لتصل لجميع الأعضاء");
		}catch(er){console.log(er)}
	}
})

bot.action('Balance', ctx => {
    if (data[ctx.from.id]==undefined)
	{
		start_button(ctx);
	}
	else
	{
		data[ctx.from.id].state="";
		__L_str=["رصيدك الحالي: "
		,"tu saldo ahora: "
		,"Your balance now: "]
		try{
		bot.telegram.sendMessage(ctx.chat.id, __L_str[data[ctx.from.id].myLang]+data[ctx.from.id].Bal);
		}catch(er){console.log(er)}
	}
})

bot.action('Transfer', ctx => {
    if (data[ctx.from.id]==undefined)
	{
		start_button(ctx);
	}
	else
	{
		data[ctx.from.id].state="";
		if (data[ctx.from.id].Bal<1)
		{
			__L_str=["للاسف لا يوجد لديك رصيد كافي لتحويله"
			,"Desafortunadamente, no tienes saldo para Transferir"
			,"Unfortunately, you do not have a balance to Transfer"]
			try{
			bot.telegram.sendMessage(ctx.chat.id, __L_str[data[ctx.from.id].myLang]);
			}catch(er){console.log(er)}
		}
		else
		{
			__L_str=['رصيدك الحالي: '+data[ctx.from.id].Bal+"\n\nقم بادخال المبلغ الذي تريد تحويله"
			,'tu saldo ahora: '+data[ctx.from.id].Bal+"\n\nIngresa el monto que deseas Transferir"
			,'Your balance now: '+data[ctx.from.id].Bal+"\n\nEnter the amount you want to Transfer"]
			try{
			bot.telegram.sendMessage(ctx.chat.id, __L_str[data[ctx.from.id].myLang]);
			}catch(er){console.log(er)}
			data[ctx.from.id].state="Transfer";
		}
	}
})

bot.action('Deposit', ctx => {
    if (data[ctx.from.id]==undefined)
	{
		start_button(ctx);
	}
	else
	{
		__L_str=["قم بادخال المبلغ الذي تريد شحنه لحسابك"
			,"Ingresa el monto que deseas cargar a tu cuenta"
			,"Enter the amount you want to charge to your account"]
		try{
		bot.telegram.sendMessage(ctx.chat.id,__L_str[data[ctx.from.id].myLang]);
		}catch(er){console.log(er)}
		data[ctx.from.id].state="Deposit";
	}
})

bot.action('Withdraw', ctx => {
	if (data[ctx.from.id]==undefined)
	{
		start_button(ctx);
	}
	else
	{
		data[ctx.from.id].state="";
		if (data[ctx.from.id].Bal==0)
		{
			__L_str=["للاسف لا يوجد لديك رصيد لسحبه"
			,"Desafortunadamente, no tienes saldo para retirar"
			,"Unfortunately, you do not have a balance to withdraw"]
			try{
			bot.telegram.sendMessage(ctx.chat.id, __L_str[data[ctx.from.id].myLang]);
			}catch(er){console.log(er)}
		}
		else
		{
			__L_str=['رصيدك الحالي: '+data[ctx.from.id].Bal+"\n\nقم بادخال المبلغ الذي تريد سحبه"
			,'tu saldo ahora: '+data[ctx.from.id].Bal+"\n\nIngresa el monto que deseas retirar"
			,'Your balance now: '+data[ctx.from.id].Bal+"\n\nEnter the amount you want to withdraw"]
			try{
			bot.telegram.sendMessage(ctx.chat.id, __L_str[data[ctx.from.id].myLang]);
			}catch(er){console.log(er)}
			data[ctx.from.id].state="Withdraw";
		}
	}
})

bot.action('Refferls', ctx => {
	if (data[ctx.from.id]==undefined)
	{
		start_button(ctx);
	}
	else
	{
		data[ctx.from.id].state="";
		__L_str=["تفضل رابط الاحالة الخاص بك:\n"
		,"Prefiere su enlace de referencia:\n"
		,"Prefer your referral link:\n"]
		try{
		bot.telegram.sendMessage(ctx.chat.id, ctx.from.id+"\n"+__L_str[data[ctx.from.id].myLang]+"https://t.me/"+MyBot+"?start="+Buffer.from(ctx.from.id.toString()).toString('base64'));
		}catch(er){console.log(er)}
	}
})

bot.action('My team', ctx => {
	if (data[ctx.from.id]==undefined)
	{
		start_button(ctx);
	}
	else
	{
		data[ctx.from.id].state="";
		if (data[ctx.from.id].MyTeam[0].length==0
		&& data[ctx.from.id].MyTeam[1].length==0
		&& data[ctx.from.id].MyTeam[2].length==0
		&& data[ctx.from.id].MyTeam[3].length==0
		&& data[ctx.from.id].MyTeam[4].length==0)
		{
			__L_str=["لا يوجد لديك اعضاء في فريقك حتى الآن"
			,"Aún no tienes miembros del equipo"
			,"You have no team members yet"]
			try{
			bot.telegram.sendMessage(ctx.chat.id,__L_str[data[ctx.from.id].myLang]);
			}catch(er){console.log(er)}
		}
		else
		{
			
			//__L_str0=['أعضاء فريقك:','los miembros de tu equipo:','your team members:']
			
			try{
			for(var j=0;j<4;j++)
			{
				__num=j+1;
				__L_str=["\n\nأعضاء فريق المستوى "+__num+":"
				,"\n\nmiembros del equipo de nivel "+__num+":"
				,"\n\nlevel "+__num+" team members:"]
				__str=__L_str[data[ctx.from.id].myLang];
				if (data[ctx.from.id].MyTeam[j].length>0)
				{
					//__str+= __L_str[data[ctx.from.id].myLang];
					for(var i=0;i<data[ctx.from.id].MyTeam[j].length;i++)
					{
						if (data[data[ctx.from.id].MyTeam[j][i]]!=undefined)
						{
							__str+="\n"+data[data[ctx.from.id].MyTeam[j][i]].first_name;
							if (data[data[ctx.from.id].MyTeam[j][i]].last_name){__str+=" "+data[data[ctx.from.id].MyTeam[j][i]].last_name;}
							__str+=" -> "+data[data[ctx.from.id].MyTeam[j][i]].Bal+"$";
						}
					}
				}
				
				bot.telegram.sendMessage(ctx.chat.id, __str);
			}
			}catch(er){console.log(er)}
		}
	}
})

bot.action('Support', ctx => {
	if (data[ctx.from.id]==undefined)
	{
		start_button(ctx);
	}
	else
	{
		data[ctx.from.id].state="";
		__L_str=['تفضل بالتواصل مع الحساب التالي للدعم الفني:\n'+support_account
		,"Comuníquese con la siguiente cuenta para obtener soporte técnico\n"+support_account
		,"Please contact the following account for technical support\n"+support_account]
		try{
		bot.telegram.sendMessage(ctx.chat.id, __L_str[data[ctx.from.id].myLang]);
		}catch(er){console.log(er)}
	}
})

bot.action('Main group', ctx => {
	if (data[ctx.from.id]==undefined)
	{
		start_button(ctx);
	}
	else
	{
		data[ctx.from.id].state="";
		__L_str=["تفضل بالاشتراك في الجروب الرئيسي:\n\n"+main_group_link
		,"Suscríbete al grupo principal:\n\n"+main_group_link
		,"Please subscribe to the main group:\n\n"+main_group_link]
		try{
		bot.telegram.sendMessage(ctx.chat.id, __L_str[data[ctx.from.id].myLang]);
		}catch(er){console.log(er)}
	}
})

bot.on('text', async (ctx) => {
	try{
	if (data[ctx.from.id]==undefined)
	{
		start_button(ctx);
	}
	else
	{
		if (data[ctx.from.id].state=="")
		{
			//if (ctx.message.text=="العربية"){data[ctx.from.id].myLang=0;SaveData()}
			//if (ctx.message.text=="English"){data[ctx.from.id].myLang=2;SaveData()}
			//if (ctx.message.text=="Spanish"){data[ctx.from.id].myLang=1;SaveData()}			
			start_button(ctx);
		}
		else if (data[ctx.from.id].state=="Transfer")
		{
			__num=isNaN(parseInt(ctx.message.text)) ? 0 : parseInt(ctx.message.text);
			if (__num==NaN || __num<=0)
			{
				data[ctx.from.id].state="";
				__L_str=["لم يتم التعرف على المبلغ الذي أدخلته"
				,"No se reconoce el importe que has introducido"
				,"The amount you entered is not recognized"]
				
				bot.telegram.sendMessage(ctx.chat.id, __L_str[data[ctx.from.id].myLang]);
			}
			else
			{
				if (__num<10)
				{
					data[ctx.from.id].state="";
					__L_str=["أقل مبلغ للتحويل 10 دولار"
					,"El monto mínimo de Transferir es de $10"
					,"The minimum Transfer amount is $10"]
					
					bot.telegram.sendMessage(ctx.chat.id, __L_str[data[ctx.from.id].myLang]);
				}
				else if (__num>data[ctx.from.id].Bal)
				{
					data[ctx.from.id].state="";
					__L_str=["الرقم الذي أدخلته أكبر من رصيدك"
					,"El número que ingresó es mayor que su saldo"
					,"The number you entered is greater than your balance"]
					
					bot.telegram.sendMessage(ctx.chat.id, __L_str[data[ctx.from.id].myLang]);
				}
				else
				{
					__L_str=["تفضل بإدخال id الشخص المحول له"
					,"Ingrese la identificación de la persona a la que está transfiriendo"
					,"Please enter the ID of the person you are transferring to"]
					
					data[ctx.from.id].Bal_d_pending=__num;
					data[ctx.from.id].state="Transfer_e";
					bot.telegram.sendMessage(ctx.chat.id,__L_str[data[ctx.from.id].myLang]);
				}
			}
			SaveData();
		}
		else if (data[ctx.from.id].state=="Transfer_e")
		{
			if (data[ctx.message.text]==undefined)
			{
				__L_str=["لم يتم التعرف على الid "
				,"No se reconoce el id"
				,"The id is not recognized"];
				bot.telegram.sendMessage(ctx.chat.id,__L_str[data[ctx.from.id].myLang]);
			}
			else
			{
				data[ctx.from.id].Bal -= data[ctx.from.id].Bal_d_pending;
				data[ctx.message.text].Bal += data[ctx.from.id].Bal_d_pending;
				SaveData();
				__L_str=["تم تحويل المبلغ بنجاح"
				,"El importe ha sido transferido con éxito"
				,"The amount has been transferred successfully"];
				bot.telegram.sendMessage(ctx.chat.id,__L_str[data[ctx.from.id].myLang]);
			}
			
			data[ctx.from.id].state="";
			
		}
		else if (data[ctx.from.id].state=="Withdraw")
		{
			__num=isNaN(parseInt(ctx.message.text)) ? 0 : parseInt(ctx.message.text);
			if (__num==NaN || __num<=0)
			{
				data[ctx.from.id].state="";
				__L_str=["لم يتم التعرف على المبلغ الذي أدخلته"
				,"No se reconoce el importe que has introducido"
				,"The amount you entered is not recognized"]
				
				bot.telegram.sendMessage(ctx.chat.id, __L_str[data[ctx.from.id].myLang]);
			}
			else
			{
				if (__num<10)
				{
					data[ctx.from.id].state="";
					__L_str=["أقل مبلغ للسحب 10 دولار"
					,"El monto mínimo de retiro es de $10"
					,"The minimum withdrawal amount is $10"]
					
					bot.telegram.sendMessage(ctx.chat.id, __L_str[data[ctx.from.id].myLang]);
				}
				else if (__num>data[ctx.from.id].Bal)
				{
					data[ctx.from.id].state="";
					__L_str=["الرقم الذي أدخلته أكبر من رصيدك"
					,"El número que ingresó es mayor que su saldo"
					,"The number you entered is greater than your balance"]
					
					bot.telegram.sendMessage(ctx.chat.id, __L_str[data[ctx.from.id].myLang]);
				}
				else
				{
					__L_str=["تفضل قم بادخال محفظتك"
					,"Por favor ingrese su billetera"
					,"Please enter your wallet"]
					
					data[ctx.from.id].Bal_d_pending=__num;
					data[ctx.from.id].state="Withdraw_e";
					bot.telegram.sendMessage(ctx.chat.id,__L_str[data[ctx.from.id].myLang]);
				}
			}
			SaveData();
		}
		else if (data[ctx.from.id].state=="Withdraw_e")
		{
			__L_str=["تم خصم المبلغ من رصيدك وسيتم تنفيذ التحويل خلال دقائق"
			,"El monto ha sido descontado de su saldo y la transferencia se ejecutará en minutos"
			,"The amount has been deducted from your balance and the transfer will be executed within minutes"];
			
			
			data[ctx.from.id].state="";
			__pocket=ctx.message.text;
			data[ctx.from.id].Bal -= data[ctx.from.id].Bal_d_pending;
			bot.telegram.sendMessage(ctx.chat.id,__L_str[data[ctx.from.id].myLang]);
			bot.telegram.sendMessage(ID_channel,"Withdraw\n"+data[ctx.from.id].username+"\n"+ctx.from.id+"\n"+data[ctx.from.id].Bal_d_pending+"\n"+__pocket);
			SaveData();
		}
		else if (data[ctx.from.id].state=="Deposit")
		{
			__num=isNaN(parseInt(ctx.message.text)) ? 0 : parseInt(ctx.message.text);
			if (__num==NaN || __num==0)
			{
				data[ctx.from.id].state="";
				__L_str=["لم يتم التعرف على المبلغ الذي أدخلته"
					,"No se reconoce el importe que has introducido"
					,"The amount you entered is not recognized"]
				
				bot.telegram.sendMessage(ctx.chat.id, __L_str[data[ctx.from.id].myLang] );
			}
			else if (__num<10)
			{
				data[ctx.from.id].state="";
				__L_str=["أقل مبلغ للايداع 10 دولار"
					,"El depósito mínimo es de $10"
					,"The minimum deposit amount is $10"]
				
				bot.telegram.sendMessage(ctx.chat.id, __L_str[data[ctx.from.id].myLang] );
			}
			else
			{
				__L_str=["قم بتحويل "+__num+" الى محفظتنا\n\n"+"\n\nوسيتم التاكد من تحويلك خلال دقائق واضافة الرصيد الى حسابك"
				,"Transferir "+__num+" a la billetera\n\n"+"\n\nSu transferencia se confirmará en minutos y el saldo se agregará a su cuenta"
				,"Transfer "+__num+" to the wallet\n\n"+"\n\nYour transfer will be confirmed within minutes and the balance will be added to your account"]
				
				
				data[ctx.from.id].state="";
				bot.telegram.sendMessage(ctx.chat.id, MyPocket);
				bot.telegram.sendMessage(ctx.chat.id, __L_str[data[ctx.from.id].myLang]);
				bot.telegram.sendMessage(ID_channel,"Deposit\n"+data[ctx.from.id].username+"\n"+ctx.from.id+"\n"+ctx.message.text);
			}
			SaveData();
			//ctx.deleteMessage();
		}
		else if (data[ctx.from.id].state=="Deposit_admin")
		{
			__num=isNaN(parseInt(ctx.message.text)) ? 0 : parseInt(ctx.message.text);
			if (__num==NaN || __num==0)
			{
				data[ctx.from.id].state="";
				__L_str=["لم يتم التعرف على المبلغ الذي أدخلته"
					,"No se reconoce el importe que has introducido"
					,"The amount you entered is not recognized"]
				
				bot.telegram.sendMessage(ctx.chat.id, __L_str[data[ctx.from.id].myLang] );
			}
			else
			{
				data[ctx.from.id].Bal_i_pending=__num;
				data[ctx.from.id].state="Deposit_admin0";
				bot.telegram.sendMessage(ctx.chat.id, "ادخل id الحساب الذي تريد شخنه");
			}
			SaveData();
			//ctx.deleteMessage();
		}
		else if (data[ctx.from.id].state=="Deposit_admin0")
		{
			data[ctx.from.id].state="";
			
			if (data[ctx.message.text]==undefined)
			{
				bot.telegram.sendMessage(ctx.chat.id, "لم يتم العثور على حساب بهذا الاسم");
			}
			else
			{
				data[ctx.message.text].Bal += data[ctx.from.id].Bal_i_pending;	
				bot.telegram.sendMessage(ctx.chat.id,"تم شحن\n"+ctx.message.text+"\n"+"بمبلغ : "+data[ctx.from.id].Bal_i_pending);
			}
			SaveData();
			//ctx.deleteMessage();
		}
		else if (data[ctx.from.id].state=="reset_admin")
		{
			data[ctx.from.id].state="";
			
			if (data[ctx.message.text]==undefined)
			{
				bot.telegram.sendMessage(ctx.chat.id, "لم يتم العثور على حساب بهذا الاسم");
			}
			else
			{
				data[ctx.message.text].Bal=0;	
				bot.telegram.sendMessage(ctx.chat.id,"تم تصفير الحساب");
			}
			SaveData();
		}
		else if (data[ctx.from.id].state=="msg_all_admin")
		{
			data[ctx.from.id].state="";
			i=0;
			for(var key in data) {
				if (data.hasOwnProperty(key)) {
					setTimeout(async function(_id,txt){
						try{
						await bot.telegram.sendMessage(_id, txt);
						}catch(er){console.log(er)}
					}, 1000*2*i, data[key].chat,ctx.message.text);
				}
				i++;
			}
		}
	}
	}catch(er){console.log(er)}
});

bot.launch();


job = schedule.scheduleJob({hour: 0, minute: 0, tz: 'Africa/Cairo'}, function(){
	for(var key in data) {
		if (data.hasOwnProperty(key)) {
			if (data[key].Bal > 0)
			{
				data[key].Bal_Day_inc=(data[key].Bal*.6)/100;
				data[key].Bal += data[key].Bal_Day_inc;
			}
		}
	}
	_arr_=[10,8,5,2];
	for(var key in data) {
		if (data.hasOwnProperty(key)) {
			for(var j=0;j<4;j++)
			{
				if (data[key].MyTeam[j].length>0)
				{
					for(var i=0;i<data[key].MyTeam[j].length;i++)
					{
						if (data[data[key].MyTeam[j][i]]!=undefined)
						{
							data[key].Bal += (data[data[key].MyTeam[j][i]].Bal_Day_inc*(_arr_[j]))/100;
						}
					}
				}
			}
		}
	}
});

